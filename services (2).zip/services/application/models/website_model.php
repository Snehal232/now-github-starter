<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Website_model extends CI_Model {
	public function __construct()
        {
                $this->load->database();
        }
	//select service details
	public function select_service($id){
		$this->db->select('*');
		$this->db->from('services');
		$this->db->where('service_id', $id);
		$query=$this->db->get(); 
		return $query->row();
	}
	
	
	
	//insert into table
	function db_add($tablename,$data)
		{
		   return $this->db->insert($tablename, $data);
		}	
	function db_update($tablename,$data,$columnname,$id)
	{
		echo $this->db->where($columnname,$id);
		return $this->db->update($tablename,$data); 
	
	}
	//delete from table
	function db_delete($tablename,$columnname,$id)
	{

		$query = $this->db->where($columnname, $id);
		return $this->db->delete($tablename);
	}
	function fetchsingledata($fieldname,$tblname,$where)
	{
		echo "select ".$fieldname." from ".$tblname." where ".$where." ";
		
		$query=$this->db->query("SELECT ".$fieldname." FROM ".$tblname." where ".$where." ");
		return  $query->result_array(); 
	}
	function fetchdata($fieldname,$tblname)
	{
		//echo "select ".$fieldname." from ".$tblname;
		$query=$this->db->query("SELECT ".$fieldname." FROM ".$tblname);
		return  $query->result_array(); 
	}
	function fetchindustry($fieldname,$tblname,$where)
	{
		$qr="SELECT ".$fieldname." FROM ".$tblname." where ".$where." ";
		$query=$this->db->query($qr);
		return $query->result_array(); 
	}
	public function get_request($user_id,$condition)
	{
		$this->db->select('interested_co.*,request.*,company.*');
        $this->db->from('interested_co');//('tbl_favorite_products AS fp');
        $this->db->join('request','interested_co.req_id = request.request_id');
        $this->db->join('company', 'interested_co.company_id = company.company_id');
        $this->db->where($condition);
        $query=$this->db->get(); 
		return $query->result_array();
		//$result = $this->db->get()->result_array();
	}

	   function add_data($tablename,$fieldarray,$condition)
	{
	   // Query to check whether username already exist or not
		
		$this->db->select('*');
		$this->db->from($tablename);
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 0)
		{
			// Query to insert data in database
			$this->db->insert($tablename, $fieldarray);
			if ($this->db->affected_rows() > 0)
			{
				return true;
			}
		}
		else
		{
			return false;
		}
	}

	public function login($tablename,$data,$condition)
	{
		$this->load->database();
		//$condition = "email =" . "'" . $data['username'] . "' AND " . "password =" . "'" . $data['password'] . "'";
		$this->db->select('*');
		$this->db->from($tablename);
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();

		if ($query->num_rows() == 1)
		{
		return true;
		}
		else
		{
		return false;
		}
	}

	public function read_user_info($tablename,$email)
	{
		$this->load->database();
		$condition = "email =" . "'" . $email . "'";
		$this->db->select('*');
		$this->db->from($tablename);
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();

		if ($query->num_rows() == 1)
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}

	public function read_user_info1($tablename,$condition)
	{
		$this->load->database();
		//$condition = "email =" . "'" . $email . "'";
		$this->db->select('*');
		$this->db->from($tablename);
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();

		if ($query->num_rows() == 1)
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}

    public function get_data($tablename){
    	$query = $this->db->get($tablename);
		return $query->result_array();
    }

    public function get_all_request($user_id)
	{
		$this->db->select('request.*,interested_co.*');
        $this->db->from('request');
        $this->db->join('interested_co', 'request.request_id = interested_co.req_id','left');
        //$this->db->join('products AS p', 'pt.for_id = p.id','left');
        $this->db->where('request.customer_id', $user_id);
		$result = $this->db->get()->result_array();
		//echo $ci->db->last_query(); die;
		return $result;
	}

	/*public function all_request($user_id)
	{
		$this->load->database();
		$condition = "req_id =" . "'" . $user_id . "' AND " . "quot !=" . "'0'";
		$this->db->select('*');
		$this->db->from('interested_co');
		$this->db->where($condition);
		$query = $this->db->get();
		return $query->result_array();
	}*/

}