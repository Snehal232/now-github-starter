<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Available extends CI_Controller {
public function __construct(){
	parent::__construct();
		$this->session->userdata('item');
		$this->load->library(array('session','google','form_validation','table','cart',));
		$this->load->helper(array('form', 'url', 'captcha','date'));
		$this->load->model('website_model');

	}

	public function index()
	{
		$this->load->view('header.php');
		$service = "services";
		$data['services']= $this->website_model->get_data($service);
		$city="city";
		$data['city']= $this->website_model->get_data($city);
		$this->load->view('index',$data);
		$this->load->view('footer.php');
	}
	public function about(){
		$this->load->view('header.php');
		$this->load->view('about.php');
		$this->load->view('footer.php');
	}

	public function services(){
		$this->load->view('header.php');
		$this->load->view('services.php');
		$this->load->view('footer.php');
	}
	public function interested_company()
	{	
		echo $id= $this->uri->segment(3);
		$condition = "req_id =" . "'" . $id. "' AND " . "quot !=" . "'" .'0'. "'";
		$data['company'] = $this->website_model->get_request($id,$condition);
		//print_r($data);
		$this->load->view('interested_company.php',$data);
	}
	public function contact(){
		$this->load->view('header.php');
		$this->load->view('contact.php');
		$this->load->view('footer.php');
	}
	public function status(){
		$this->load->view('header.php');
		$customer_id = $this->session->userdata['customer_logged_in']['id'];
		$condition = "customer_id =" . "'" . $customer_id. "'";
		$data['result'] = $this->website_model->fetchindustry('*','request',$condition);
		//print_r($data);
		$this->load->view('status.php',$data);
		$this->load->view('footer.php');
	}

	public function quot_accept(){
		echo $id= $this->uri->segment(3);	
		//$condition = "interested_id =" . "'" . $id. "'";
		$data = array(
			'req_status' => 'quot_accept'
			);
		$data['company'] = $this->website_model->db_update('interested_co',$data,'interested_id',$id);
		
	}

	public function register(){
		$table="login";
		//$this->load->view('header.php');
		//$this->load->view('register.php');
		//$this->load->view('footer.php');
		if (empty($_POST)) {
			//$this->load->view('user_registration_form');
			$this->load->view('register.php');
		} 
		else {
			$data = array(
			'user_name' => $this->input->post('first_name').' '. $this->input->post('last_name'),
			'email' => $this->input->post('email'),
			'phone' => $this->input->post('phone'),
			'password' => $this->input->post('password'),
			'oauth_provider' => 'form'
			);
				
			$condition = "email =" . "'" . $data['email'] . "'";
			$result = $this->website_model->add_data($table,$data,$condition);
			if ($result == TRUE) {
				$data['loginURL'] = $this->google->loginURL();
				$data['message_display'] = 'Registration Successfully !';
				$this->load->view('login', $data);
			}
			else {
				echo "<script type='text/javascript'> alert('Email already exist!'); </script>";
				$data['message_display'] = 'Email already exist!';
				$this->load->view('register', $data);
			}
		}
	}
	public function login_process() 
	{
		if(isset($this->session->userdata['customer_logged_in']))
		{
			$this->load->view('conform_order');
		}
		else
		{
			redirect("available/login");
		}
	}

	public function login() 
	{
		$table="login";
		if(isset($_GET['code'])){   
			// Authenticate user with google
            if($this->google->getAuthenticate())
            {	
            	// Get user info from google
	        	$gpInfo = $this->google->getUserInfo();
	              
	        	// Preparing data for database insertion
	        	$userData['user_name']     = $gpInfo['given_name'] .' '.$gpInfo['family_name'];
	            $userData['email']          = $gpInfo['email'];
	            $userData['password']          = '';
	            $userData['oauth_provider'] = 'google';
	                
	            // Insert or update user data to the database
	            $condition = "email =" . "'" . $data['email'] . "'";
	            $this->website_model->add_data($table,$userData,$condition);
	            $email = $gpInfo['email'];
	            $result = $this->website_model->read_user_info($table,$email);
	            if ($result != false)
	            {
	               	$session_data = array('id'=>$result[0]->id,
	            					'user_name' => $result[0]->user_name,
	                    	        'email' => $result[0]->email,
	                    		    );
	                // Add user data in session
	                $this->session->set_userdata('customer_logged_in', $session_data);
	                // Redirect to profile page
	                redirect("available");
	            }
        	}	
		}
		$data['loginURL'] = $this->google->loginURL();
        		
		$this->form_validation->set_rules('user_name', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		if ($this->form_validation->run() == FALSE){
			$this->load->view('login',$data);
		}
		else
		{
			$data = array(
				'username' => $this->input->post('user_name'),
				'password' => $this->input->post('password'),
			);
			$condition = "email =" . "'" . $data['username'] . "' AND " . "password =" . "'" . $data['password']. "'";
			$result = $this->website_model->login($table,$data,$condition);
			if ($result == TRUE)
			{
				$email = $this->input->post('user_name');
				$result = $this->website_model->read_user_info($table,$email);
				if ($result != false)
				{
					$session_data = array(
						'id'=>$result[0]->id,
						'user_name' => $result[0]->user_name,
						'email' => $result[0]->email,
					);
					// Add user data in session
					$this->session->set_userdata('customer_logged_in', $session_data);
					redirect("Available");
				}
			}
			else{
				$data = array(
				'error_message' => 'Invalid Username or Password'
				);
				$data['loginURL'] = $this->google->loginURL();
				$this->load->view('login', $data);
			}
		}
	}

	public function get_request(){
		$table="request";
		if(isset($this->session->userdata['customer_logged_in']))
		{
			$data = array(
					'customer_id' => $this->input->post('customer_id'),
					'trade_type' => $this->input->post('trade_type'),
					'city' => $this->input->post('city'),
					'address' => $this->input->post('address'),
					'description' => $this->input->post('job_description'),
					'date' => $this->input->post('date'),
					'requested_date' => date("y-m-d")
					);
			$this->website_model->db_add($table,$data);
			echo'<script>alert("Thnaks")</script>';?>
			<script>window.location.href="<?php echo base_url(); ?>index.php/available";</script>
		<?php
		}
		else
		{
			echo'<script>alert("Login First")</script>';?>
			<script>window.location.href="<?php echo base_url(); ?>index.php/available/login";</script>
		<?php }
	}

	public function logout()
	{
		// Removing session data
		$sess_array = array(
		'username' => ''
		);
		$this->session->unset_userdata('customer_logged_in', $sess_array);
		echo $data['message_display'] = 'Successfully Logout';
		//$this->load->base_url().'index.php/Available';
		echo "<script>alert('This card was not approved, Thanks.');</script>";
		redirect("Available");
	}

	
}
