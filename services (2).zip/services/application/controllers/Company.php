<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class company extends CI_Controller {
public function __construct(){
	parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('session');
		$this->load->model('website_model');
		$this->load->library('form_validation');
		$this->load->library('image_lib');
	}

	public function home()
	{
		$this->load->view('company/header.php');
		$this->load->view('company/index.php');
		$this->load->view('company/footer.php');
	}

	public function remove_trade($id)
	{
		$tablename  = "industry";
		$columnname = "ind_id";
		$this->website_model->db_delete($tablename,$columnname,$id);
		redirect('company/industry');
	}

	public function add_trade()
	{
		$this->load->view('company/header.php');
		$service = "services";
		$data['services']= $this->website_model->get_data($service);
		$city="city";
		$data['city']= $this->website_model->get_data($city);
		$this->load->view('company/add_trade.php',$data);
		$this->load->view('company/footer.php');
	}

	public function insert_trade()
	{	
		$table="industry";
		$data = array(
				'company_name' => $this->input->post('company_name'),
				'company_id' => $this->input->post('company_id'),
				'trade_type' => $this->input->post('trade_type'),
				'contact' => $this->input->post('contact'),
				'email' => $this->input->post('email'),
				'location' => $this->input->post('location'),
			);
		$this->website_model->db_add($table,$data);
		redirect('company/industry');
	}

	//company->manage company
	public function industry(){
		$this->load->view('company/header.php');
		$company_name = ($this->session->userdata['company_logged_in']['user_name']);
		$table="industry";
		$condition = "company_name =" . "'" . $company_name . "'";
		$data['info'] = $this->website_model->fetchindustry('*',$table,$condition);
		$this->load->view('company/view_industry.php',$data);
		$this->load->view('company/footer.php');		
	}

	public function login(){
		$table="company";
	
		//$this->load->view('company/login.php');	

		$this->form_validation->set_rules('user_name', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		if ($this->form_validation->run() == FALSE){
			$this->load->view('company/login');
		}
		else
		{
			$username = $this->input->post("user_name");
			echo $username;
			$data = array(
				'username' => $this->input->post('user_name'),
				'password' => $this->input->post('password'),
			);
			$condition = "company_email =" . "'" . $data['username'] . "' AND " . "password =" . "'" . $data['password'] . "'";
			$result = $this->website_model->login($table,$data,$condition);
			if ($result == TRUE)
			{
				$email = $this->input->post('user_name');
				$condition = "company_email =" . "'" . $email . "'";
				$result = $this->website_model->read_user_info1($table,$condition);
				if ($result != false)
				{
					$session_data = array(
						'id'=>$result[0]->company_id,
						'user_name' => $result[0]->company_name,
						'email' => $result[0]->company_email,
					);
					// Add user data in session
					$this->session->set_userdata('company_logged_in', $session_data);
					redirect("company/home");
				}
			}
			else{
				$data = array(
				'error_message' => 'Invalid Username or Password'
				);
				$this->load->view('company/login', $data);
			}
		}
	}

	public function register()
	{
		
		$table="company";
		
		if (empty($_POST)) {
			$city="city";
		$data['city']= $this->website_model->get_data($city);
			$this->load->view('company/register.php',$data);	
		} 

		else {
			$data = array(
			'company_name' => $this->input->post('company_name'),
			'company_email' => $this->input->post('company_email'),
			'company_phone' => $this->input->post('company_phone'),
			'company_website' => $this->input->post('company_website'),
			'head_office' => $this->input->post('city'),
			'password' => $this->input->post('password')
			);

			$condition = "company_email =" . "'" . $data['company_email'] . "'";
			$result = $this->website_model->add_data($table,$data,$condition);
			if ($result == TRUE) {
				$data['message_display'] = 'Registration Successfully !';
				$this->load->view('company/login', $data);
			}
			else {
				echo "<script type='text/javascript'> alert('Email already exist!'); </script>";
				$data['message_display'] = 'Email already exist!';
				$this->load->view('company/register', $data);
			}
		}
	}
}
