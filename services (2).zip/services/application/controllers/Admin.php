<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {
public function __construct(){
	parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('session');
		$this->load->model('website_model');
		$this->load->library('form_validation');
		$this->load->library('image_lib');
	}

	public function home()
	{
		$this->load->view('admin/header.php');
		$this->load->view('admin/index.php');
		$this->load->view('admin/footer.php');
	}
	public function orders(){
		/*if(!empty($_POST['city'])){
			$query=$city = $_POST['city'];	
			$fieldname = '*';
			$tblname = 'request';
			$where = "city = '$city'";
			$request['info'] = $this->website_model->fetchsingledata($fieldname,$tblname,$where);
			print_r($request);
			//$this->load->view('admin/header.php');
			//$this->load->view('admin/view_orders.php',$request);
			//$this->load->view('admin/footer.php');	
		}else{*/
		$request['info'] = $this->website_model->get_request();
		//print_r($request);exit();
		$request['city'] = $this->website_model->fetchdata('*','city');
		$request['trade'] = $this->website_model->fetchdata('*','services');
		$this->load->view('admin/header.php');
		$this->load->view('admin/view_orders.php',$request);
		$this->load->view('admin/footer.php');	
		//}	
	}	
	
	public function services(){
		//echo "hii";exit();
		$services['info'] = $this->website_model->fetchdata('*','services');
		//print_r($services);exit();
		$this->load->view('admin/header.php');
		$this->load->view('admin/view_services.php',$services);
		$this->load->view('admin/footer.php');
		
	}
	public function services1(){
		$id = $_POST['service_id'];		
	 	$service = $this->website_model->select_service($id);
			$service->service_id;
			$service->service_type;
			$service->service_desc;
				print_r(json_encode($service));
	}
	//Add service
	public function add_service(){
		$this->load->view('admin/header.php');
		$this->load->view('admin/add_service.php');
		$this->load->view('admin/footer.php');
		//$id = $_POST['id'];
		$data=array(
			'service_type' => $this->input->post('id'),
			'service_type' => $this->input->post('name'),
			'service_desc' => $this->input->post('desc')
			);
		
		//$this->website_model->update_services($id,$data);
		//redirect('admin/services');
	}
	//update service
	public function update_service(){
		$id = $_POST['id'];
		$tablename="services";
		$columnname="service_id";
		$data=array(
			'service_type' => $this->input->post('name'),
			'service_desc' => $this->input->post('desc')
			);
		
		$this->website_model->db_update($tablename,$data,$columnname,$id);
		redirect('admin/services');
	}
	//update service
	public function delete_service($id){
		$tablename="services";
		$columnname = "service_id";
		$this->website_model->db_delete($tablename,$columnname,$id);
		redirect('admin/services');
	}
	//image upload and add product into table
	public function insert_service(){
	  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
	  $this->form_validation->set_rules('name', 'Service Type', 'required|min_length[5]|max_length[15]');
	  $this->form_validation->set_rules('desc', 'Description', 'required|min_length[5]|max_length[500]');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('admin/header');
			$this->load->view('admin/add_service');
			$this->load->view('admin/footer');
		}else{
			$config = array(
				'upload_path' => "./assets/admin/img/",
				'allowed_types' => "gif|jpg|png|jpeg|pdf",
				'overwrite' => TRUE,
				'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				'max_height' => "768",
				'max_width' => "1024",
				
				);
			
			$this->load->library('upload', $config);
			if($this->upload->do_upload()){//echo "hi";exit();
				$data = array('upload_data' => $this->upload->data());
				$img=$data['upload_data']['file_name'];
				 $configer =  array(
				              'image_library'   => 'gd2',
				              'source_image'    =>  './assets/admin/img/'.$img,
				              'maintain_ratio'  =>  false,
				              'width'           =>  225,
				              'height'          =>  225
				            );
				$this->image_lib->clear();
				$this->image_lib->initialize($configer);
				    if (!$this->image_lib->resize()) {
				        echo $this->image_lib->display_errors();
				    }else{ 
				    	$tablename="services";
						$data = array('upload_data' => $this->upload->data());
						$data = array(
							'service_type' => $this->input->post('name'),
							'service_desc' => $this->input->post('desc'),
							'image' => $this->upload->data('file_name'),
							);
						
						//Transfering data to Model
						$this->website_model->db_add($tablename,$data);
							$data['message'] = 'Data Inserted Successfully';
							//Loading View						
						$this->load->view('admin/header');
						$this->load->view('admin/add_service', $data);
						$this->load->view('admin/footer');
						
					}
			}else{
				$error = array('error' => $this->upload->display_errors());
				$this->load->view('admin/custom_view', $error);
				}
		}
	}
	//admin->manage company
	public function company(){
		$this->load->view('admin/header.php');
		$this->load->view('admin/view_company.php');
		$this->load->view('admin/footer.php');		
	}

}
