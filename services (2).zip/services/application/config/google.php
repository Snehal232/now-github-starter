<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
|  Google API Configuration
| -------------------------------------------------------------------
| 
| To get API details you have to create a Google Project
| at Google API Console (https://console.developers.google.com)
| 
|  client_id         string   Your Google API Client ID.
|  client_secret     string   Your Google API Client secret.
|  redirect_uri      string   URL to redirect back to after login.
|  application_name  string   Your Google application name.
|  api_key           string   Developer key.
|  scopes            string   Specify scopes
*/
$config['google']['client_id']  = '168966788547-r7ng340nsqf61mldjtevm8obg50740rj.apps.googleusercontent.com';
$config['google']['client_secret']    = '7rZaJRW0TUB-8yBHq5EAuZ2G';
$config['google']['redirect_uri']     = 'http://localhost/services/index.php/available/login';
$config['google']['application_name'] = 'Available ';
$config['google']['api_key']          = '';
$config['google']['scopes']           = array();