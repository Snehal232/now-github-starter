	<!-- //header -->
	<div class="banner-bg2">
		<div class="banner-info bg3 inner">
			<h3>one click repair service</h3>
			<p>repair.&nbsp;improve.&nbsp;maintain</p>
		</div>
	</div>
	<!-- breadcrumbs -->
	<div class="breadcrumbs-w3l">
		<div class="container">
			<span class="breadcrumbs">
				<a href="index.html">Home</a> |
				<span> Services</span>
			</span>
		</div>
	</div>
	<!-- //breadcrumbs -->
	<!-- /services -->
	<div class="services w3ls-section">
		<div class="container">
			<h4 class="main-title">services offered</h4>
			<div class="services-main">
				<div class="col-md-4 serv-grid1">
					<!-- <h4 class="sub1">your complete home solution</h4> -->
					<h4 class="sub1">services that you need we will provide at your door step</h4>

				</div>
				<div class="col-md-8 serv-grid2">
					<div class="col-md-4 serv-sub1">
						<img src="<?php echo base_url(); ?>assets/images/t8.png" alt="" />
						<h5>electrical service</h5>
					</div>
					<div class="col-md-4 serv-sub1">
						<img src="<?php echo base_url(); ?>assets/images/t5.png" alt="" />
						<h5>plumbing service</h5>
					</div>
					<div class="col-md-4 serv-sub1">
						<img src="<?php echo base_url(); ?>assets/images/t3.jpg" alt="" />
						<h5>cleaning</h5>
					</div>
					<div class="col-md-4 serv-sub1">
						<img src="<?php echo base_url(); ?>assets/images/t6.png" alt="" />
						<h5>home appliances</h5>
					</div>
					<div class="col-md-4 serv-sub1">
						<img src="<?php echo base_url(); ?>assets/images/t7.png" alt="" />
						<h5>painting service</h5>
					</div>
					<div class="col-md-4 serv-sub1">
						<img src="<?php echo base_url(); ?>assets/images/t2.jpg" alt="" />
						<h5>carpentry</h5>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //services -->
	<div class="container">
		<div class="single-left serv-bottom">
			<h5 class="main-title">complete home services
			</h5>
			<div class="post-media col-md-7">
				<img src="<?php echo base_url(); ?>assets/images/g6.jpg" class="img-responsive" alt="">
				<div class="blog-text">
					<h5>Quo modo autem philosophus</h5>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Non semper, inquam; Quo modo autem philosophus loquitur? Duo
						Reges: constructio interrete. Dici enim nihil potest verius. Hic ambiguo ludimur. An hoc usque quaque, aliter in vita?
						Bonum incolumis acies: misera caecitas. Favorite</p>
				</div>
			</div>
			<div class="all-comments col-md-5">
				<div class="media-grids">
					<div class="w3l-media">
						<h5>plumbing services</h5>
						<div class="media-body">
							<p>Maecenas ultricies rhoncus tincidunt maecenas imperdiet ipsum id ex pretium hendrerit maecenas imperdiet ipsum id
								ex pretium hendrerit</p>
							<a href="projects.html"> view more </a>
						</div>
					</div>
					<div class="w3l-media">
						<h5>electrical services</h5>
						<div class="media-body">
							<p>Maecenas ultricies rhoncus tincidunt maecenas imperdiet ipsum id ex pretium hendrerit maecenas imperdiet ipsum id
								ex pretium hendrerit</p>
							<a href="projects.html"> view more </a>
						</div>
					</div>
					<div class="w3l-media">
						<h5>painting services</h5>
						<div class="media-body">
							<p>Maecenas ultricies rhoncus tincidunt maecenas imperdiet ipsum id ex pretium hendrerit maecenas imperdiet ipsum id
								ex pretium hendrerit</p>
							<a href="projects.html"> view more </a>
						</div>
					</div>

				</div>


			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="w3ls-section app-head">
		<div class="container">
			<div class="col-md-4 col-sm-4 app-mobile">
				<img src="<?php echo base_url(); ?>assets/images/mobile.png" alt="" class="img-responsive" />
			</div>
			<div class="col-md-8 col-sm-8 app-main">
				<h6>home services at your
					<span>finger tips!</span>
				</h6>
				<div class="app-form">
					<p>get the SMS link to download free app </p>
					<form action="#" method="post" class="banner_form">
						<div class="sec-left">
							<input placeholder="Enter your mobile #" name="first name" type="text" required="">
						</div>
						<input type="submit" value="get the app">
						<div class="clearfix"></div>
					</form>
				</div>
				<ul class="app-links">
					<li>
						<a href="#">
							<img src="<?php echo base_url(); ?>assets/images/1.png" alt="">
						</a>
					</li>
					<li>
						<a href="#">
							<img src="<?php echo base_url(); ?>assets/images/2.png" alt="">
						</a>
					</li>
				</ul>

			</div>
			<div class="clearfix"></div>
		</div>
	</div>