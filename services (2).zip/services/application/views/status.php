	<div class="banner-bg2" hidden>
		<div class="banner-info bg3 inner">
			<h3>one click repair service</h3>
			<p>repair.&nbsp;improve.&nbsp;maintain</p>
		</div>
	</div>
	<!-- breadcrumbs -->
	<div class="breadcrumbs-w3l">
		<div class="container">
			<span class="breadcrumbs">
				<a href="index.html">Home</a> |
				<span>Status</span>
			</span>
		</div>
	</div>
	<!-- //breadcrumbs -->
	<!-- track order -->

	<div class="w3ls-section">
		<div class="container">
			<div class="register-top">
				
				<div class="col-md-12 col-sm-12 ">
					<div class="table-responsive">
		            	<table class="table table-hover" id="myTable">
		                	<thead>
		                    	<tr>
		                        	<th >#</th>
		                        	<th>Trade Type</th>
		                        	<th>Date of working</th>
		                        	<th>Interested Companies</th>
		                        	<th>Company Name</th>
		                        	<th>Status</th>
		                    	</tr>
		                	</thead>
		                	<tbody>
							<?php  
							    foreach ($result as $request) {?>     
							    <tr> 
							        <td><?php echo '#'.$request['request_id'];?></td>
							        <td><?php echo $request['trade_type'];?></td>
							        <td><?php echo $request['date'];?></td>
							        <td><?php $id=$request['request_id'];echo anchor("available/interested_company/$id",'<button type="button" class="btn-sm btn-danger">View</button>');?></td>
									<td></td>
									<td><?php echo $request['status']?></td>
									<?php } ?>
								</tr>
		               		</tbody>
		            	</table>
        			</div>
   				 </div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
</div>
	<!-- //track order -->

	<div class="w3ls-section app-head" hidden>
		<div class="container">
			<div class="col-md-4 col-sm-4 app-mobile">
				<img src="<?php echo base_url();?>/assets/images/mobile.png" alt="" class="img-responsive" />
			</div>
			<div class="col-md-8 col-sm-8 app-main">
				<h6>home services at your
					<span>finger tips!</span>
				</h6>
				<div class="app-form">
					<p>get the SMS link to download free app </p>
					<form action="#" method="post" class="banner_form">
						<div class="sec-left">
							<input placeholder="Enter your mobile #" name="first name" type="text" required="">
						</div>
						<input type="submit" value="get the app">
						<div class="clearfix"></div>
					</form>
				</div>
				<ul class="app-links">
					<li>
						<a href="#">
							<img src="<?php echo base_url();?>/assets/images/1.png" alt="">
						</a>
					</li>
					<li>
						<a href="#">
							<img src="<?php echo base_url();?>/assets/images/2.png" alt="">
						</a>
					</li>
				</ul>

			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- register -->

	<div class="w3ls-section banner-single" id="register" hidden>
		<div class="container">
			<h4 class="main-title">get registered!</h4>
			<div class="about-inner-main">
				<div class="col-md-5 reg-img">
					<img src="<?php echo base_url();?>/assets/images/girl.png" alt="" class="img-responsive" />
				</div>
				<div class="col-md-7  w3layouts-reg-form">
					<form action="#" method="post" class="banner_form">
						<p>Please fill your details as mentioned below </p>
						<div class="sec-left">
							<label class="contact-form-text">Name</label>
							<input placeholder="your name " name="first name" type="text" required="">
						</div>
						<div class="sec-right">
							<label class="contact-form-text">Email</label>
							<input placeholder="xxx@xx.com " name="first name" type="email" required="">
						</div>
						<div class="sec-left">
							<label class="contact-form-text">Mobile no.</label>
							<input placeholder=" XXXXXX" name="first name" type="text" required="">
						</div>
						<div class="form-tx">
							<label class="contact-form-text">Address</label>
							<textarea placeholder="your address" required></textarea>
						</div>
						<div class="form-select sec-left">
							<label class="contact-form-text">Select Category</label>
							<select>
								<option value="0">---- SELECT ----</option>
								<option value="1">Electrical Service</option>
								<option value="2">Plumbing Service</option>
								<option value="3">Painting</option>
								<option value="4">Carpentry</option>
								<option value="5">Gardening</option>
								<option value="6">Other</option>
							</select>
						</div>
						<div class="form-select sec-right">
							<label class="contact-form-text">Select Area</label>
							<select>
								<option value="0">---- SELECT ----</option>
								<option value="1">place1</option>
								<option value="2">place2</option>
								<option value="3">place3</option>
								<option value="4">place4</option>
								<option value="5">place5</option>
							</select>
						</div>
						<div class="clearfix"></div>
						<div class="form-select">
							<label class="contact-form-text">Select Plan</label>
							<select>
								<option value="0">---- SELECT ----</option>
								<option value="1">Normal plan (free)</option>
								<option value="2">First preference $50</option>
								<option value="3">Second preference $38</option>
								<option value="4">Third preference $25</option>
							</select>
						</div>
						<div class="wthree-text">
							<ul>
								<li>
									<label class="anim">
										<input type="checkbox" class="checkbox">
										<span> I accept the terms and conditions</span>
									</label>
								</li>
							</ul>
							<div class="clearfix"> </div>
						</div>
						<input type="submit" value="Submit">
					</form>

				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //register -->