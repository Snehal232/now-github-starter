
<?php $this->load->view('header.php');?>


<div class="banner-bg2" hidden="">
			<div class="banner-info bg3 inner" >
					<h3>one click repair service</h3>
					<p>repair.&nbsp;improve.&nbsp;maintain</p>
				</div>
	</div>
	<!-- breadcrumbs -->
	<div class="breadcrumbs-w3l" hidden="">
		<div class="container">
			<span class="breadcrumbs">
				<a href="index.html">Home</a> |
				<span>Plans</span>
			</span>
		</div>
	</div>

	<!-- plan -->
	<div class="w3ls-section plans" style="padding-bottom: 4em;">
		<div class="container">
			<h4 class="main-title">Company</h4>
			<div class="services-main">
				<!-- maintenance essential plan -->
				<?php  
				foreach ($company as $request) {?>
				<div class="col-md-4 col-sm-4 w3_agile-plan-grid">
					<div class="pricing_grid_content">
						<h5><?php echo $request['company_name']?></h5>
						<h3>
							<sup>Rs.</sup>
							<span class="counter agile_counter"><?php echo $request['quot']?>
							</span>
						</h3>
						<ul class="w3_count">
							<li>
								<span class="fa fa-check" aria-hidden="true"></span>
								<?php echo $request['company_phone']?>
							</li>
							<li>
								<span class="fa fa-check" aria-hidden="true"></span>
								<?php echo $request['company_email']?>
							</li>
							<li>
								<span class="fa fa-check" aria-hidden="true"></span>
								<?php echo $request['company_website']?>

						</ul>
						<?php  $id=$request['interested_id'];
						if($request['req_status'] == "quot_accept"){?>
							<button disabled="" class="btn" style=" float:left;"> Accepted</button>
						
						<?php } else { 
							 
							 echo anchor("available/quot_accept/$id",'<button class="btn" style="float:left;"> Accept</button>');
							}
							 echo anchor("available/quot_reject/$id",'<button class="btn" style="float:right;">Reject</button>');?>
					</div>
				</div>
				<?php } ?>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //plan -->
	<div class="w3ls-section app-head" hidden="">
			<div class="container">
				<div class="col-md-4 col-sm-4 app-mobile"><img src="<?php echo base_url();?>/assets/images/mobile.png" alt="" class="img-responsive"/></div>
				<div class="col-md-8 col-sm-8 app-main">
					<h6>home services at your <span>finger tips!</span></h6>
					<div class="app-form">
							<p>get the SMS link to download free app </p>
							<form action="#" method="post" class="banner_form">
							<div class="sec-left">
									<input  placeholder="Enter your mobile #" name="first name" type="text" required="">
							</div>	
							<input type="submit" value="get the app">
							<div class="clearfix"></div>
							</form>
					</div>
					<ul class="app-links">
							<li><a href="#"><img src="<?php echo base_url();?>/assets/images/1.png" alt=""></a></li>
							<li><a href="#"><img src="<?php echo base_url();?>/assets/images/2.png" alt=""></a></li>
					</ul>
					
				</div>	
				<div class="clearfix"></div>
			</div>
		</div>
		<?php $this->load->view('footer.php');?>