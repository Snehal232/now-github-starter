<?php
if (isset($this->session->userdata['customer_logged_in'])) {
	$id = ($this->session->userdata['customer_logged_in']['id']);
	$username = ($this->session->userdata['customer_logged_in']['user_name']);
	$email = ($this->session->userdata['customer_logged_in']['email']);
}
?>
	<!-- banner -->
	<div class="banner-silder">
		<div id="JiSlider" class="jislider">
			<ul>
				<li>
					<div class="banner-top banner-top1">
						<div class="container">
							<div class="banner-info info2">
								<h3>one stop home services</h3>
								<p>let us do it for you.</p>

							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="banner-top banner-top2">
						<div class="container">
							<div class="banner-info bg3 info2">
								<h3>one click repair service</h3>
								<p>repair.&nbsp;improve.&nbsp;maintain</p>
							</div>

						</div>
					</div>
				</li>
				<li>
					<div class="banner-top banner-top3">
						<div class="container">
							<div class="banner-info bg3">
								<h3>Property Maintenance Services</h3>
								<p>one call does it all.</p>
							</div>

						</div>
					</div>
				</li>
			</ul>
		</div>
		<!-- //banner -->
		<!-- banner bottom -->
		<div class="banner-btm">
			<div class="container">
				<div class="banner-bottom-main">
					<div class="col-md-4 banner-btmg1">

						<div class="form-text">
							<h3>Looking for a Handyman?</h3>
							<p>We solve your Home repair needs!</p>
							<img src="<?php echo base_url(); ?>assets/images/f1.png" alt="" />
						</div>
						<form action="<?php echo base_url()."index.php/available/get_request"?>" method="post" class="banner_form" id="request">
							<?php if (isset($this->session->userdata['customer_logged_in'])) {?>
							<input type="text" name="customer_id" value="<?php echo $id?>" hidden>
							<?php } else {?>
								<input type="text" name="customer_id" value="" hidden>
								<?php } ?>
							<div class="form-select sec-right" >
								<label class="contact-form-text">Select Trade Type</label>
								<select name="trade_type">
									<option value="0">---- SELECT ----</option>
									<?php foreach($services as $service){?>
										<option value="<?php echo $service['service_type'];?>"><?php echo $service['service_type'];?></option>
									<?php	}	?>
								</select>
								<p><span class="val_trade_type"></span></p>
							</div>
							<div class="form-select sec-right" >
								<label class="contact-form-text">Select City</label>
								<select name="city">
									<option value="0">---- SELECT ----</option>
									<?php foreach($city as $city){?>
										<option value="<?php echo $city['city_name'];?>"><?php echo $city['city_name'];?></option>
									<?php	}	?>
								</select>
								<p><span class="val_city"></span></p>
							</div>
							<div class="form-tx">
								<label class="contact-form-text">Enter Your City, Town Or Village</label>
								<textarea placeholder="your address" name="address" required="" rowspan="4"></textarea>
								<p><span class="val_address"></span></p>
							</div>
							<div class="form-tx">
								<label class="contact-form-text">Short Description of Job/Project</label>
								<textarea placeholder="Description" name="job_description" required=""></textarea>
								<p><span class="val_job_description"></span></p>
							</div>
							<div class="sec-right">
								<label class="contact-form-text">Date When Work Is Required To Start </label>
								<input placeholder="Date & Time" id="datetimepicker1" type="text" name="date" required="">
								<p><span class="val_date"></span></p>
							</div>
							<input type="submit" name="submit" value="Submit">
						</form>
					</div>
					<div class="col-md-8 banner-btm-grid2">
						<div class="col-md-4 banner-grid2">
							<div class="banner-subg1">
								<h3>maintenance</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit estibulum nibh urna scing.</p>
								<span class="fa fa-cog" aria-hidden="true"></span>
								<div class="read-btn">
									<a href="<?php echo site_url();?>/available/about">view more</a>
								</div>
							</div>
							<div class="banner-subg1">
								<h3>cleaning</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit estibulum nibh urna scing.</p>
								<span class="fa fa-check-square-o" aria-hidden="true"></span>
								<div class="read-btn">
									<a href="<?php echo site_url();?>/available/about">view more</a>
								</div>
							</div>

						</div>
						<div class="col-md-4 banner-grid2">
							<div class="banner-subg1">
								<h3>repair</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit estibulum nibh urna scing.</p>
								<span class="fa fa-yelp" aria-hidden="true"></span>
								<div class="read-btn">
									<a href="<?php echo site_url();?>/available/about">view more</a>
								</div>
							</div>
							<div class="banner-subg1">
								<h3>improvement</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit estibulum nibh urna scing.</p>
								<span class="fa fa-gg" aria-hidden="true"></span>
								<div class="read-btn">
									<a href="<?php echo site_url();?>/available/about">view more</a>
								</div>
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<!-- //banner bottom -->
		<!-- about -->
		<div class="agile-about-main">
			<div class="col-md-4 about-left">
				<div class="about-main-bg text-center">
					<h4 class="about-title">Why</h4>
					<h4 class="sub">
						<span>c</span>hoose
						<span>u</span>s?</h4>
				</div>
			</div>
			<div class="col-md-8 about-bottom-g1">
				<h4>One Stop Solution for your Complete Home Maintenance</h4>
				<!-- <h4>get easy home repairs and upgrades with professional home service providers</h4> your complete home solution.-->
				<div class="about-grid">
					<div class="about-bottom-right">
						<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive fa fa-check"> </span>
						</div>
						<div class="about-bottom">
							<h5>vision</h5>
							<p>Consectetur adipiscing elit estibulum nibh urna</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="about-bottom-right">
						<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive  fa fa-book"> </span>
						</div>
						<div class="about-bottom">
							<h5>affordable</h5>
							<p>Elit consectetur adipiscing estibulum nibh urna</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class=" about-bottom-right">
						<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive fa fa-photo"> </span>
						</div>
						<div class="about-bottom">
							<h5>quality</h5>
							<p>Consectetur adipiscing elit estibulum nibh urna</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class=" about-bottom-right">
						<div class="abouthome-grid">
							<span class="hi-icon hi-icon-archive fa fa-briefcase"> </span>
						</div>
						<div class="about-bottom">
							<h5>24*7 support</h5>
							<p>Adipiscing consectetur elit estibulum nibh urna</p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="abt-img">
					<img src="<?php echo base_url(); ?>assets/images/a1.png" alt="" class="img-responsive" />
				</div>
				<div class="clearfix"></div>
			</div>

			<div class="clearfix"></div>
		</div>
	</div>
	<!-- //about -->
	<!--  about bottom -->
	<div class="w3ls-section">
		<div class="container">
			<div class="main-bottom">
				<div class="col-md-6 col-sm-6 mb-left">

				</div>
				<div class="col-md-6 col-sm-6 mb-right">
					<h4>service you can trust</h4>
					<p>protect all your home appliances & systems.</p>
					<a href="<?php echo site_url();?>/available/services">view all services</a>
				</div>

			</div>
		</div>
	</div>

<script type="text/javascript">
	jQuery(function() {
	var validation_holder;
		
		$("form#request input[name='submit']").click(function() {
			var validation_holder = 0;

			var trade_type 			= $("form#request select[name='trade_type']").val();
			var city 			 	= $("form#request select[name='city']").val();
			var address 			= $("form#request textarea[name='address']").val();
			var job_description		= $("form#request textarea[name='job_description']").val();
			var date 		 	 	= $("form#request input[name='date']").val();	
			
			/* validation start */	
			if(trade_type == "0") {
				$("span.val_trade_type").html("Please select Trade type.").addClass('validate');
				validation_holder = 1;
			} 
			else{
				$("span.val_trade_type").html("");
			}

			if(city == "0") {
				$("span.val_city").html("Please select City.").addClass('validate');
				validation_holder = 1;
			} 
			else{
				$("span.val_city").html("");
			}

			if(address == "") {
				$("span.val_address").html("Enter Address.").addClass('validate');
				validation_holder = 1;
			}
			else {
				$("span.val_address").html("");
			}

			if(job_description == "") {
				$("span.val_job_description").html("Enter Description.").addClass('validate');
				validation_holder = 1;
			} 
			else {
					$("span.val_job_description").html("");
			}

			if(date == "") {
				$("span.val_date").html("Enter Date and Time.").addClass('validate');
				validation_holder = 1;
			} 
			else {
					$("span.val_date").html("");
			}

			if(validation_holder == 1) { // if have a field is blank, return false
				$("p.validate_msg").slideDown("fast");
				return false;
			}  validation_holder = 0; // else return true
			/* validation end */	
		}); // click end 
	}); // jQuery End
</script>