<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>A2Z a Corporate Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="a2z Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script> 
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //for-mobile-apps -->
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--banner slider  -->
	<link href="<?php echo base_url(); ?>assets/css/JiSlider.css" rel="stylesheet">
	<!-- //banner-slider -->
	<link href="<?php echo base_url(); ?>assets/css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="//fonts.googleapis.com/css?family=Noto+Serif:400,400i,700,700i" rel="stylesheet">
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-datetimepicker.min.css">
</head>

<body>
	<!-- header -->
	<div class="w3layouts-header">
		<div class="container">

			<div class="logo-nav-agileits" hidden>
				<div class="logo-nav-left">
					<h1>
						<a href="index.html">
							<span class="fa fa-home"></span>a2z
							<span class="logo-title">home services</span>
						</a>
					</h1>
				</div>

				<div class="header-grid-left-wthree">
					<div class="h3-title">
						<h3>contact us</h3>
					</div>
					<ul>
						<li>
							<span class="fa fa-envelope" aria-hidden="true"></span>
							<a href="mailto:info@example.com">a2zservices.com</a>
						</li>
						<li>
							<span class="fa fa-phone" aria-hidden="true"></span>+1234 567 892</li>
						<li>
							<span class="fa fa-mobile" aria-hidden="true"></span>+12 234 5678
						</li>
					</ul>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
			<div class="logo-nav-left1">
				<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">Menu
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>

					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav">
							<li class="<?php if($this->uri->segment(2) =='index'){echo 'active';}?>">
								<a href="<?php echo site_url();?>/available/index">Home</a>
							</li>
							<li class="<?php if($this->uri->segment(2) =='about'){echo 'active';}?>">
								<a href="<?php echo site_url();?>/available/about">about us</a>
							</li>
							<li class="<?php if($this->uri->segment(2) =='services'){echo 'active';}?>">
								<a href="<?php echo site_url();?>/available/services">services</a>
							</li>
							<li>
								<a href="projects.html">Projects</a>
							</li>
							<li>
								<a href="plan.html">plans</a>
							</li>
							<li class="<?php if($this->uri->segment(2) =='contact'){echo 'active';}?>">
								<a href="<?php echo site_url();?>/available/contact">contact us</a>
							</li>
							<li class="<?php if($this->uri->segment(2) =='status'){echo 'active';}?>">
								<a href="<?php echo site_url();?>/available/status">track request status</a>
							</li>
							<?php if (isset($this->session->userdata['customer_logged_in'])) { ?>
							<li class="s-bar">
								<div class="search-w3_agileits">
									<input class="search_box" type="checkbox" id="search_box">
									<label class="icon-search" for="search_box">
										<span><?php echo $user_name=$this->session->userdata['customer_logged_in']['user_name'];?></span>
									</label>
									<div class="search_form">
											<a id ="logout" href="<?php echo base_url();?>index.php/available/logout">Logout</a>
									</div>
								</div>
							</li>
							<?php }
							else {?>
								<li class="<?php if($this->uri->segment(2) =='login'){echo 'active';}?>">
								<a href="<?php echo base_url();?>index.php/available/login">Login</a>
							</li>
								
							<?php } ?>

						</ul>
					</div>

				</nav>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //header -->