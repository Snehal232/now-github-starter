<?php
if (isset($this->session->userdata['company_logged_in'])) {
echo $id = ($this->session->userdata['company_logged_in']['id']);
echo $username = ($this->session->userdata['company_logged_in']['user_name']);
} else {
header("location: login");
}
?>

<!-- Forms-1 -->
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
    <h4 class="tittle-w3-agileits mb-4">Add Service</h4>
    <form action="<?php echo base_url(); ?>company/insert_trade" method="post" enctype="multipart/form-data">
        
        <div class="form-group row"hidden>
            <label for="inputPassword3" class="col-sm-2 col-form-label">Contact Number</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="company_id" name="company_id" placeholder="Contact Number" value="<?php echo $id ?>">
                 <input type="text" class="form-control" id="company_name" name="company_name" placeholder="Contact Number" value="<?php echo $username ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Trade Type</label>
            <div class="col-sm-10">
               <select class="form-control" name="trade_type">
                    <option value="0">---- SELECT ----</option>
                    <?php foreach($services as $service){?>
                    <option value="<?php echo $service['service_type'];?>"><?php echo $service['service_type'];?></option>
                    <?php   }   ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Contact Number</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="desc" name="contact" placeholder="Contact Number" required="">
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
                <input type="email" class="form-control" id="desc" name="email" placeholder="Email " required="">
            </div>
        </div>
         <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Location</label>
            <div class="col-sm-10">
                    <select name="location" class="form-control">
                        <option value="0">---- SELECT ----</option>
                        <?php foreach($city as $city){?>
                        <option value="<?php echo $city['city_name'];?>"><?php echo $city['city_name'];?></option>
                        <?php   }   ?>
                    </select>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
</div>
<!--// Forms-1 -->