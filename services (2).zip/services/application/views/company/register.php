<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Modernize an Admin Panel Category Bootstrap Responsive Web Template | Register :: w3layouts</title>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Modernize Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <style type="text/css">
        span.validate {
    color: #F00;
    font-style: italic;
}
    </style>
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }

    </script>
    <!-- //Meta Tags -->

    <!-- Style-sheets -->
     <!-- Bootstrap Css -->
    <link href="<?php echo base_url()?>assets/admin/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Css -->
    <!-- Common Css -->
    <link href="<?php echo base_url()?>assets/admin/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!--// Common Css -->
    <!-- Fontawesome Css -->
    <link href="<?php echo base_url()?>assets/admin/css/fontawesome-all.css" rel="stylesheet">
    <!--// Fontawesome Css -->
    <!--// Style-sheets -->
    <!--web-fonts-->
    <link href="//fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!--//web-fonts-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.min.js"></script>
</head>

<body>
    <div class="bg-page py-5">
        <div class="container">
            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center text-white">Register</h2>
            <!--// main-heading -->
            <div class="form-body-w3-agile text-center w-lg-50 w-sm-75 w-50 mx-auto mt-5">
                <form method="post" id="registration" action="<?php echo base_url()."index.php/company/register"?>">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Enter username" required="" name="company_name">
                         <p><span class="val_company_name"></span></p>
                    </div>
                    <div class="form-group">
                        <input type="email" name="company_email" class="form-control" placeholder="Enter email" required="">
                         <p><span class="val_company_email"></span></p>
                    </div>
                    <div class="form-group">
                        <input type="text" name="company_phone" class="form-control" placeholder="Enter Contact Number" required="">
                         <p><span class="val_company_phone"></span></p>
                    </div>
                    <div class="form-group">
                        <select class="form-control" style="padding: 0.5em 1em;" name="city">
                                     <option value="0" disabled selected>Select City</option>
                                    <?php foreach($city as $city){?>
                                        <option value="<?php echo $city['city_name'];?>"><?php echo $city['city_name'];?></option>
                                    <?php   }   ?>
                                </select>
                                <p><span class="val_city"></span></p>
                    </div>
                    <div class="form-group">
                        <input type="text" name="company_website" class="form-control" placeholder="Enter Company Website" required="">
                         <p><span class="val_company_name"></span></p>
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Password" required="">
                         <p><span class="val_password"></span></p>
                    </div>
                    <div class="form-group">
                        <input type="password" name="conform_password" class="form-control" placeholder="Confirm Password" required="">
                         <p><span class="val_conform_password"></span></p>
                    </div>
                    <div class="form-check text-center">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Agree the terms and policy</label>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary error-w3l-btn mt-sm-5 mt-3 px-4">Submit</button>
                </form>
                <p class="paragraph-agileits-w3layouts mt-4">Already have account?
                    <a href="<?php echo base_url()?>index.php/company/login">Login</a>
                </p>
            </div>
        </div>
    </div>

</body>

</html>


   <!-- Required common Js -->
    <script src='<?php echo base_url()?>assets/admin/js/jquery-2.2.3.min.js'></script>
    <!-- //Required common Js -->

     <!-- Js for bootstrap working-->
    <script src="<?php echo base_url()?>assets/admin/js/bootstrap.min.js"></script>
    <!-- //Js for bootstrap working -->
<script type="text/javascript">
    jQuery(function() {
    var validation_holder;
    
    $("form#registration button[name='submit']").click(function() {
      
    var validation_holder = 0;
    
        var company_name         = $("form#registration input[name='company_name']").val();
        var company_email        = $("form#registration input[name='company_email']").val();
        var user_email_regex     = /^[\w%_\-.\d]+@[\w.\-]+.[A-Za-z]{2,6}$/; // reg ex email check 
        var company_phone        = $("form#registration input[name='company_phone']").val();
        var phone_regex          = /^([0-9]{10})*$/; // reg ex phone check  
        var company_website      = $("form#registration input[name='company_website']").val(); 
        var password             = $("form#registration input[name='password']").val(); 
        var conform_password     = $("form#registration input[name='conform_password']").val();
        var city                = $("form#request select[name='city']").val();
        
        
        /* validation start */  
        if(company_name == "") {
            $("span.val_company_name").html("Company Name is Empty.").addClass('validate');
            validation_holder = 1;
        } else {
            $("span.val_company_name").html("");
        }

        if(city == "0") {
                $("span.val_city").html("Please select City.").addClass('validate');
                validation_holder = 1;
        } 
        else{
            $("span.val_city").html("");
        }

        if(company_website == "") {
            $("span.val_company_website").html("Company Website is Empty.").addClass('validate');
            validation_holder = 1;
        } else {
            $("span.val_company_website").html("");
        }        

        if(company_email == "") {
            $("span.val_company_email").html("Email is required.").addClass('validate');
            validation_holder = 1;
        } 
        else {
            if(!user_email_regex.test(company_email)){ // if invalid email
                $("span.val_company_email").html("Invalid Email!").addClass('validate');
                validation_holder = 1;
            } else {
                $("span.val_company_email").html("");
            }
        }

        if(password == "") {
            $("span.val_password").html("Password is required.").addClass('validate');
            validation_holder = 1;
        } 
        else {
                $("span.val_password").html("");
        }

        if(conform_password == "") {
            $("span.val_conform_password").html("Password is required.").addClass('validate');
            validation_holder = 1;
        } 
        else {
                if(password != conform_password) {
                    $("span.val_conform_password").html("Password does not match!").addClass('validate');
                    validation_holder = 1;
                } else {
                    $("span.val_conform_password").html("");
                };
        }

        if(company_phone == "") {
            $("span.val_company_phone").html("Phone Number is required.").addClass('validate');
            validation_holder = 1;
        } 
        else {
            if(!phone_regex.test(company_phone)){ // if invalid phone
                $("span.val_company_phone").html("Invalid Phone Number!").addClass('validate');
                validation_holder = 1;
            
            } else {
                $("span.val_company_phone").html("");
            }
        }

        if(validation_holder == 1) { // if have a field is blank, return false
            $("p.validate_msg").slideDown("fast");
            return false;
        }  validation_holder = 0; // else return true
        /* validation end */    
    }); // click end 

}); // jQuery End
</script>