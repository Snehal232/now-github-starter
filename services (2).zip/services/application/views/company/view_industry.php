 <?php
if (isset($this->session->userdata['company_logged_in'])) {
echo $username = ($this->session->userdata['company_logged_in']['user_name']);
} else {
header("location: login");
}
?>
<!-- main-heading -->
<h2 class="main-title-w3layouts mb-2 text-center">Orders</h2>
<!--// main-heading -->

<div class="container-fluid">
<div class="row">
<!-- Stats -->
<div class="outer-w3-agile col-xl">
    <div class="work-progres">
        
        <span style="float:right;margin-bottom: 10px;">
                <?php
                echo anchor("company/add_trade",'<button type="button" class="add btn btn-success">Add Service</button>');?>
                
            </span>
        <select id="citySelect" size="1"  hidden>
            <option selected hidden>Choose City</option>
            <?php foreach($city as $city_name){?>
               <option value="<?php echo $city_name['city_name'];?>">
                    <?php echo $city_name['city_name'];?>
                </option> 
            <?php
            }
            ?>
        </select>
        <select id="tradeSelect" size="1" hidden >
            <option selected hidden>Choose Trade</option>

            <?php 
             print_r($trade);
            foreach($trade as $service){?>
               <option value="<?php echo $service['trade_type'];?>">
                    <?php echo $service['trade_type'];?>
                </option> 
            <?php
            }
            ?>
        </select>
       
        <div class="table-responsive">
            <table class="table table-hover" id="myTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Trade Type</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>location</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
<?php  
    foreach ($info as $request) {?>     
                    <tr> 
                        <td><?php echo '#'.$request['ind_id'];?></td>
                        <td><?php echo $request['trade_type'];?></td>
                        <td><?php echo $request['contact'];?></td>
                        <td><?php echo $request['email'];?></td>
                        <td><?php echo $request['location'];?></td>
                         <td><?php $id=$request['ind_id'];
                            echo anchor("company/remove_trade/$id",'<button type="button" class="btn-sm btn-danger">remove</button>');
                            ?>
                        </td>
                    </tr>
                <?php    }  ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
/*function choice1(select) {
    var city=select.options[select.selectedIndex].text
     //alert(city);
        jQuery.ajax({       
          url: "http://localhost/available/admin/orders/",
          type: "POST",
          dataType: "html",
          data: {city: city},
            success: function(data){ 
                //alert(data);   
                $('#new').html(data);   
                var obj = JSON.parse(data);
                $('#new').html(obj);   
                /*var id = obj.service_id;
                var name = obj.service_type;
                var desc = obj.service_desc;
                var img = obj.image;

                $('#id').val(id);
                $('#name').val(name);
                $('#desc').val(desc);
                $('img-fluid').html(img);
                
              return true;
            },
        });
}*/

$(document).ready(function($) {
  $('table').show();

  $('#tradeSelect').change(function() {
    
    var selection = $(this).val();
    var dataset = $('#myTable tbody').find('tr');
    // show all rows first
    dataset.show();
    // filter the rows that should be hidden

    dataset.filter(function(index, item) { //alert("dataset"); 
      return $(item).find('td:nth-child(6)').text().split(',').indexOf(selection) === -1;
    }).hide();

  });
});
</script>