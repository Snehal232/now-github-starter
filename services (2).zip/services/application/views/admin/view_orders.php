 
<!-- main-heading -->
<h2 class="main-title-w3layouts mb-2 text-center">Orders</h2>
<!--// main-heading -->

<div class="container-fluid">
<div class="row">
<!-- Stats -->
<div class="outer-w3-agile col-xl">
    <div class="work-progres">
        <h4 class="tittle-w3-agileits mb-4"></h4>
        <select id="citySelect" size="1"  hidden>
            <option selected hidden>Choose City</option>
            <?php foreach($city as $city_name){?>
               <option value="<?php echo $city_name['city_name'];?>">
                    <?php echo $city_name['city_name'];?>
                </option> 
            <?php
            }
            ?>
        </select>
        <select id="tradeSelect" size="1"  >
            <option selected hidden>Choose Trade</option>
            <?php print_r($trade);
            foreach($trade as $service){?>
               <option value="<?php echo $service['service_type'];?>">
                    <?php echo $service['service_type'];?>
                </option> 
            <?php
            }
            ?>
        </select>
        <hr>
        <div class="table-responsive">
            <table class="table table-hover" id="myTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Name</th>
                        <th>City</th>
                        <th>Contact</th>
                        <th>Industry</th>
                        <th>Message</th>
                        <th>Date & Time</th>
                        <th>Status</th>
                        <th>Interested Co</th>
                        <th>Feedback</th>
                    </tr>
                </thead>
                <tbody>
<?php  
    foreach ($info as $request) {?>     
                    <tr> 
                        <td><?php echo '#'.$request['request_id'];?></td>
                        <td>Date</td>
                        <td><?php echo $request['user_name'];?></td>
                        <td><?php echo $request['city'];?></td>
                        <td><?php echo $request['email'];?></td>
                        <td><?php echo $request['service_type'];?></td>
                        <td><?php echo $request['description'];?></td>
                        <td><?php echo $request['date'];?></td>
                        <td>
                            <span class="badge badge-danger"><?php echo $request['status'];?></span>
                        </td>
                        <td></td>
                        <td>
                            <span class="badge badge-pill badge-primary"></span>
                        </td>
                    </tr>
                <?php    }  ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
/*function choice1(select) {
    var city=select.options[select.selectedIndex].text
     //alert(city);
        jQuery.ajax({       
          url: "http://localhost/available/admin/orders/",
          type: "POST",
          dataType: "html",
          data: {city: city},
            success: function(data){ 
                //alert(data);   
                $('#new').html(data);   
                var obj = JSON.parse(data);
                $('#new').html(obj);   
                /*var id = obj.service_id;
                var name = obj.service_type;
                var desc = obj.service_desc;
                var img = obj.image;

                $('#id').val(id);
                $('#name').val(name);
                $('#desc').val(desc);
                $('img-fluid').html(img);
                
              return true;
            },
        });
}*/

$(document).ready(function($) {
  $('table').show();
  $('#citySelect').change(function() {
    
    var selection = $(this).val();
    var dataset = $('#myTable tbody').find('tr');
    // show all rows first
    dataset.show();
    // filter the rows that should be hidden

    dataset.filter(function(index, item) { //alert("dataset"); 
      return $(item).find('td:nth-child(4)').text().split(',').indexOf(selection) === -1;
    }).hide();

  });
  $('#tradeSelect').change(function() {
    
    var selection = $(this).val();
    var dataset = $('#myTable tbody').find('tr');
    // show all rows first
    dataset.show();
    // filter the rows that should be hidden

    dataset.filter(function(index, item) { //alert("dataset"); 
      return $(item).find('td:nth-child(6)').text().split(',').indexOf(selection) === -1;
    }).hide();

  });
});
</script>