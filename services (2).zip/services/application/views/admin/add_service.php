<!-- Forms-1 -->
<div class="outer-w3-agile col-xl mt-3 mr-xl-3">
    <h4 class="tittle-w3-agileits mb-4">Add Service</h4>
    <form action="<?php echo base_url(); ?>admin/insert_service" method="post" enctype="multipart/form-data">
        
        <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 col-form-label">Service Type</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="name" name="name" placeholder="Type" required="">
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Description</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="desc" name="desc" placeholder="Description" required="">
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Upload Image</label>
            <div class="col-sm-10">
                <input type="file" class="form-control" id="userfile" name="userfile" required="">
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Sign in</button>
            </div>
        </div>
    </form>
</div>
<!--// Forms-1 -->