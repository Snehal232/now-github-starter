            <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center">Blank page</h2>
            <!--// main-heading -->

            <!-- Error Page Content -->
            <div class="blank-page-content">

                <!-- Error Page Info -->
                <div class="outer-w3-agile mt-3">
                    <p class="paragraph-agileits-w3layouts">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent mollis augue venenatis, laoreet magna
                        sed, bibendum ligula. Cras eget ultricies leo. Aenean elementum semper commodo. Sed quis vehicula
                        sapien. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur placerat massa at dolor
                        faucibus, vitae molestie lorem cursus. Integer vulputate pretium urna, at mattis nibh convallis sed.
                        Mauris suscipit dictum nulla, vel suscipit urna volutpat eu. Nunc interdum a sapien et sodales. Donec
                        et turpis quis eros convallis finibus in non sem. Suspendisse semper dui quis pellentesque porta.
                        Sed sodales risus sit amet libero vestibulum congue. Integer pulvinar nunc at dui ultrices, vel ultrices
                        nunc scelerisque. Nam facilisis ipsum sed hendrerit aliquet.</p>
                </div>
                <!--// Error Page Info -->

            </div>

            <!--// Error Page Content -->

            <!-- Copyright -->
            <div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center">
                <p>© 2018 Modernize . All Rights Reserved | Design by
                    <a href="http://w3layouts.com/"> W3layouts </a>
                </p>
            </div>
            <!--// Copyright -->
        </div>
    </div>

