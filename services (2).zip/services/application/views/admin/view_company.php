<!-- main-heading -->
<h2 class="main-title-w3layouts mb-2 text-center">Companies</h2>
<!--// main-heading -->

<div class="container-fluid">
<div class="row">
<!-- Stats -->
<div class="outer-w3-agile col-xl">
<div class="work-progres">
    <h4 class="tittle-w3-agileits mb-4">All Companies</h4>
    <hr>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Indusrty</th>
                    <th>Location</th>
                    <th>Contact</th>
                    <th>Email</th>                                          
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Date</td>
                    <td>ABC</td>
                    <td>Indusrty</td>
                    <td>Location</td>
                    <td>Contact</td>
                    <td>Email</td>   
                    <td>
                        <button type="button" class="btn-sm btn-warning open" data-toggle="modal" data-target="#exampleModal" value="<?php //echo $ser['service_id'];?>">Update</button>
                        <?php 
                        //$id=$ser['service_id'];
                        echo anchor("admin/delete_company/",'<button type="button" class="btn-sm btn-danger">Delete</button>');
                        ?>
                    </td>                                      
                </tr>
            </tbody>
        </table>
    </div>
</div>
</div>