
<!-- main-heading -->
<h2 class="main-title-w3layouts mb-2 text-center">Services</h2>
<!--// main-heading -->

<div class="container-fluid">
<div class="row">
<!-- Stats -->
<div class="outer-w3-agile col-xl">
    <div class="work-progres">
        <h4 class="tittle-w3-agileits mb-4">All Services
            <span style="float:right">
                <?php
                echo anchor("admin/add_service",'<button type="button" class="add btn btn-success">Add Service</button>');?>
                
            </span>
        </h4>

        <hr>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Serial</th>
                        <th>Name</th>
                        <th>Operation</th>
                        
                    </tr>
                </thead>
                <tbody>
                    
                <?php
                //print_r($info);
                    foreach($info as $ser){?>
                    <tr>
                        <td><?php echo $ser['service_id'];?></td>
                        <td><?php echo $ser['service_type'];?></td>
                        <td>
                            
                            <button type="button" class="btn-sm btn-warning open" data-toggle="modal" data-target="#exampleModal" value="<?php echo $ser['service_id'];?>">Update</button>
                            <?php 
                            $id=$ser['service_id'];
                            echo anchor("admin/delete_service/$id",'<button type="button" class="btn-sm btn-danger">Delete</button>');
                            ?>
                        </td>
                    </tr>
                <?php    //data-toggle="modal" data-target="#exampleModal"    
                    }
                ?>                  
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>





<!-- popup content -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="dialog" id="myform">
     <form action="update_service" method="POST">
        
        <label id="valueFromMyButton"></label>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <input type="text" hidden class="modal-title" name="id" id="id">
                <input type="text" class="modal-title" name="name" id="name">
                
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <img hidden src="<?php echo base_url()?>assets/admin/images/ban4.jpg"  class="img-fluid" alt="Responsive image">

                <div id='image_div' >
                    
                    <input type="file" class="imgupload" style="display:none" onchange='readURL(this);' name="userfile"/>
                    <a href="javascript:;">
                        <img src="<?php echo base_url()?>assets/admin/images/ban4.jpg" class="img-fluid" alt="Responsive image"/>
                    </a>
                </div>

                <textarea id="desc" name="desc" class="paragraph-agileits-w3layouts mt-3">Maecenas interdum, metus vitae tincidunt porttitor, magna quam egestas sem, ac scelerisque
                    nisl nibh vel lacus. Proin eget gravida odio. Donec ullamcorper est eu accumsan cursus.</textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button  type="submit" class="btn btn-primary">Save changes</button>
            </div>

            
               
            </div>
        </div>
     </form>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--// popup content -->

<script>
$(document).ready(function () {   
    $(".open").click(function(){
        var ths=$(this).val();
        //alert(ths);
        jQuery.ajax({       
          url: "http://localhost/available/admin/services1/",
          type: "POST",
          dataType: "html",
          data: {service_id: ths},
            success: function(data){ 
                          
                var obj = JSON.parse(data);
                var id = obj.service_id;
                var name = obj.service_type;
                var desc = obj.service_desc;
                var img = obj.image;

                $('#id').val(id);
                $('#name').val(name);
                $('#desc').val(desc);
                $('img-fluid').html(img);
                
              return true;
            },
        });
        //$("#myform #valueFromMyButton").text($(this).val().trim());
       //$('#exampleModal').modal('show');
    });
});
</script>
<script type="text/javascript">

        $(document).ready(function(){
            $(".img-fluid").click(function(){
                var ths=$(this);
                $(this).parent().prev(".imgupload").click();
            })
            $(".imgupload").change(function(){
                readURL(this);
            })
        })
    
        function readURL(input) {

          if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
              $(input).next('a').children('img').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
          }
        }
</script>

