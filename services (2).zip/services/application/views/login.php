<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>A2Z a Corporate Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script src='https://www.google.com/recaptcha/api.js'></script>
	<meta name="keywords" content="a2z Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script> 
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<style>
		span.validate {
	    color: #F00;
	    font-style: italic;
		}
	    #btn_google{
	        height: 60px;
    		width: 445px;
		    margin-top: 20px;
		}	
	</style>
	<!-- //for-mobile-apps -->
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--banner slider  -->
	<link href="<?php echo base_url(); ?>assets/css/JiSlider.css" rel="stylesheet">
	<!-- //banner-slider -->
	<link href="<?php echo base_url(); ?>assets/css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="//fonts.googleapis.com/css?family=Noto+Serif:400,400i,700,700i" rel="stylesheet">
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.0/dist/jquery.validate.min.js"></script>
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">

</head>

<body>


<!-- register -->
	<div class="w3ls-section banner-single" id="register">
		<div class="container">
			<h4 class="main-title">Login!</h4>
			<?php
				if (isset($message_display)) {
				echo "<div class='message'>";
				echo $message_display;
				echo "</div>";
				}
			?>
			<?php
				echo "<div class='error_msg'>";
				if (isset($error_message)) {
				echo $error_message;
				}
				echo validation_errors();
				echo "</div>";
			?>
			<div class="about-inner-main">
				<div class="col-md-5 reg-img">
					<img src="<?php echo base_url();?>/assets/images/girl.pn" alt="" class="img-responsive" />
				</div>
				<div class="col-md-7  w3layouts-reg-form">
					<form id="login" method="post" class="banner_form" action="<?php echo base_url()."index.php/available/login"?>">
						<div class="sec-left">
						<a href="<?php echo $loginURL; ?>"><img src="<?php echo base_url('assets/images/google.png'); ?>" id="btn_google" /></a><br><br>
						</div>
						<div class=" sec-left">
							<label class="contact-form-text">Email</label>
							<input placeholder="your name " name="user_name" type="text" required="">
							<p><span class="val_user_name"></span></p>
						</div>
						<div class="sec-left">
							<label class="contact-form-text">Password</label>
							<input placeholder=" XXXXXX" name="password" type="password" required="">
							<p><span class="val_password"></span></p>
						</div>
						<div class="sec-left">
						<label class="contact-form-text"></label>
						<div class="g-recaptcha" data-sitekey="6Lf77pAUAAAAAD7Cm-ju2U-GDqqFccKvnm_fuByZ"></div>
						</div>
						<div class="clearfix"></div>
						<center> <input type="submit" value=" Login " name="submit"/></center>
					</form>
					<a href="<?php echo base_url() ?>index.php/available/register"><span class="contact-form-text">New User Click Here</span></a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //register -->
</body>
</html>
<script>
$("form").submit(function(event) {
   var recaptcha = $("#g-recaptcha-response").val();
   if (recaptcha === "") {
      event.preventDefault();
      alert("Please check the recaptcha");
   }
});
</script>
<!-- <script type="text/javascript">
	jQuery(function() {
	var validation_holder;
	
	$("form#registration input[name='submit']").click(function() {
	var validation_holder = 0;
	
		var first_name 			 = $("form#registration input[name='first_name']").val();
		var last_name 			 = $("form#registration input[name='last_name']").val();
		var first_name_regex	 =/^[A-z]*$/;
		var last_name_regex	 	 =/^[A-z]*$/;
		var user_email 			 = $("form#registration input[name='email']").val();
		var user_email_regex 	 = /^[\w%_\-.\d]+@[\w.\-]+.[A-Za-z]{2,6}$/; // reg ex email check	
		var password 		 	 = $("form#registration input[name='password']").val();	
		var conform_password 	 = $("form#registration input[name='conform_password']").val();
		var phone 				 = $("form#registration input[name='phone']").val();
		var phone_regex			 = /^([0-9]{10})*$/; // reg ex phone check	
		
		/* validation start */	
		if(first_name == "") {
			$("span.val_first_name").html("First Name is Empty.").addClass('validate');
			validation_holder = 1;
		} else {
			if(!first_name_regex.test(first_name)){ // if invalid email
				$("span.val_first_name").html("Invalid First Name").addClass('validate');
				validation_holder = 1;
			} else {
				$("span.val_first_name").html("");
			}
		}

		if(last_name == "") {
			$("span.val_last_name").html("Last Name is Empty.").addClass('validate');
			validation_holder = 1;
		} else {
			if(!last_name_regex.test(last_name)){ // if invalid email
				$("span.val_last_name").html("Invalid Last Name").addClass('validate');
				validation_holder = 1;
			} else {
				$("span.val_last_name").html("");
			}
		}

		if(user_email == "") {
			$("span.val_email").html("Email is required.").addClass('validate');
			validation_holder = 1;
		} 
		else {
			if(!user_email_regex.test(user_email)){ // if invalid email
				$("span.val_email").html("Invalid Email!").addClass('validate');
				validation_holder = 1;
			} else {
				$("span.val_email").html("");
			}
		}


		if(password == "") {
			$("span.val_password").html("Password is required.").addClass('validate');
			validation_holder = 1;
		} 
		else {
				$("span.val_password").html("");
		}

		if(conform_password == "") {
			$("span.val_conform_password").html("Password is required.").addClass('validate');
			validation_holder = 1;
		} 
		else {
				if(password != conform_password) {
					$("span.val_conform_password").html("Password does not match!").addClass('validate');
					validation_holder = 1;
				} else {
					$("span.val_conform_password").html("");
				};
		}

		if(phone == "") {
			$("span.val_phone").html("Phone Number is required.").addClass('validate');
			validation_holder = 1;
		} 
		else {
			if(!phone_regex.test(phone)){ // if invalid phone
				$("span.val_phone").html("Invalid Phone Number!").addClass('validate');
				validation_holder = 1;
			
			} else {
				$("span.val_phone").html("");
			}
		}

		if(validation_holder == 1) { // if have a field is blank, return false
			$("p.validate_msg").slideDown("fast");
			return false;
		}  validation_holder = 0; // else return true
		/* validation end */	
	}); // click end 

}); // jQuery End
</script>  -->
