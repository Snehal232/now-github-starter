
	<div class="banner-bg2">
		<div class="banner-info bg3 inner">
			<h3>one click repair service</h3>
			<p>repair.&nbsp;improve.&nbsp;maintain</p>
		</div>
	</div>
	<!-- breadcrumbs -->
	<div class="breadcrumbs-w3l">
		<div class="container">
			<span class="breadcrumbs">
				<a href="index.html">Home</a> |
				<span>About us</span>
			</span>
		</div>
	</div>
	<!-- inner-banner-bottom -->
	<div class="w3ls-section">
		<div class="container">
			<div class="col-md-6 inner-banner">
				<h4 class="title-about about text-center">leave it to us
					<span>complete house</span> cleaning
					<span>services
					</span>
				</h4>
			</div>
			<div class="col-md-6 inner-main-bg">
				<div class="inner-bg-layer"></div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- //inner-banner-bottom  -->
	<!-- about bottom -->
	<div class="agile-about-main">
		<div class="col-md-4 about-left">
			<div class="about-main-bg text-center">
				<h4 class="about-title">Why</h4>
				<h4 class="sub">
					<span>c</span>hoose
					<span>u</span>s?</h4>
			</div>
		</div>
		<div class="col-md-8 about-bottom-g1">
			<h4>One Stop Solution for your Complete Home Maintenance</h4>
			<!-- <h4>get easy home repairs and upgrades with professional home service providers</h4> your complete home solution.-->
			<div class="about-grid">
				<div class="about-bottom-right">
					<div class="abouthome-grid">
						<span class="hi-icon hi-icon-archive fa fa-check"> </span>
					</div>
					<div class="about-bottom">
						<h5>vision</h5>
						<p>Consectetur adipiscing elit estibulum nibh urna</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="about-bottom-right">
					<div class="abouthome-grid">
						<span class="hi-icon hi-icon-archive  fa fa-book"> </span>
					</div>
					<div class="about-bottom">
						<h5>affordable</h5>
						<p>Elit consectetur adipiscing estibulum nibh urna</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class=" about-bottom-right">
					<div class="abouthome-grid">
						<span class="hi-icon hi-icon-archive fa fa-photo"> </span>
					</div>
					<div class="about-bottom">
						<h5>quality</h5>
						<p>Consectetur adipiscing elit estibulum nibh urna</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class=" about-bottom-right">
					<div class="abouthome-grid">
						<span class="hi-icon hi-icon-archive fa fa-briefcase"> </span>
					</div>
					<div class="about-bottom">
						<h5>24*7 support</h5>
						<p>Adipiscing consectetur elit estibulum nibh urna</p>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<div class="abt-img">
				<img src="<?php echo base_url(); ?>assets/images/a1.png" alt="" class="img-responsive" />
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- //about bottom-->
	<!-- Stats -->
	<div class="w3ls-section  stats">
		<div class="container">
			<h5>On time,On budget, with in Scope and with Quality.</h5>
			<div class="stats-aboutinfo services-main">
				<div class="col-sm-3 col-xs-3 agileits_w3layouts-stats-grids text-center">
					<div class="stats-icon">
						<span class="fa fa-users" aria-hidden="true"></span>
					</div>
					<div class="stats-right">
						<h6>clients</h6>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='11073' data-delay='.5' data-increment="10">11073</div>

					</div>
				</div>
				<div class="col-sm-3 col-xs-3 agileits_w3layouts-stats-grids text-center">
					<div class="stats-icon">
						<span class="fa fa-shield" aria-hidden="true"></span>
					</div>
					<div class="stats-right">
						<h6>branches</h6>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='780' data-delay='.5' data-increment="1">380</div>

					</div>

				</div>
				<div class="col-sm-3 col-xs-3 agileits_w3layouts-stats-grids text-center">
					<div class="stats-icon">
						<span class="fa fa-external-link" aria-hidden="true"></span>
					</div>
					<div class="stats-right">
						<h6>projects</h6>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='630' data-delay='.5' data-increment="1">1366</div>

					</div>
				</div>
				<div class="col-sm-3 col-xs-3 agileits_w3layouts-stats-grids text-center">
					<div class="stats-icon">
						<span class="fa fa-book" aria-hidden="true"></span>
					</div>
					<div class="stats-right">
						<h6>others</h6>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='623' data-delay='.5' data-increment="1">623</div>

					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //Stats -->
	<!-- about-slid -->
	<div class="about-slid">
		<div class="container">
			<h6 class="slid">Professional, Efficient and Reliable Plumbing Services</h6>
		</div>
	</div>
	<!-- //about-slid -->
	<!-- what we do -->
	<div id="news" class="w3ls-section">
		<div class="container">
			<h4 class="main-title">what we do?</h4>
			<div class="news-aboutinfo services-main">
				<div class=" col-md-4 col-sm-6 about-innergrids">
					<div class="agileits-news-gridtext">
						<div class="news-gridimg">
							<a href="single.html">
								<img src="<?php echo base_url(); ?>assets/images/g4.jpg" class="img-responsive zoom-img" alt="" />
							</a>
						</div>
						<div class="news-gridimgtext">
							<a href="single.html">
								<h4>home Maintenance</h4>
							</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer gravida mauris non mi gravida, at sollicitudin. </p>
						</div>
					</div>
				</div>
				<div class=" col-md-4 col-sm-6 about-innergrids">
					<div class="agileits-news-gridtext">
						<div class="news-gridimg">
							<a href="single.html">
								<img src="<?php echo base_url(); ?>assets/images/r2.jpg" class="img-responsive zoom-img" alt="" />
							</a>
						</div>
						<div class="news-gridimgtext">
							<a href="single.html">
								<h4>repair</h4>
							</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer gravida mauris non mi gravida, at sollicitudin. </p>
						</div>
					</div>
				</div>
				<div class=" col-md-4 col-sm-6 about-innergrids">
					<div class="agileits-news-gridtext">
						<div class="news-gridimg">
							<a href="single.html">
								<img src="<?php echo base_url(); ?>assets/images/g7.jpg" class="img-responsive zoom-img" alt="" />
							</a>
						</div>
						<div class="news-gridimgtext">
							<a href="single.html">
								<h4>Improvement</h4>
							</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer gravida mauris non mi gravida, at sollicitudin. </p>
						</div>
					</div>
				</div>
				<div class=" col-md-4 col-sm-6 about-innergrids">
					<div class="agileits-news-gridtext">
						<div class="news-gridimg">
							<a href="single.html">
								<img src="<?php echo base_url(); ?>assets/images/g6.jpg" class="img-responsive zoom-img" alt="" />
							</a>
						</div>
						<div class="news-gridimgtext">
							<a href="single.html">
								<h4>plumbing services</h4>
							</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer gravida mauris non mi gravida, at sollicitudin. </p>
						</div>
					</div>
				</div>
				<div class=" col-md-4 col-sm-6 about-innergrids">
					<div class="agileits-news-gridtext">
						<div class="news-gridimg">
							<a href="single.html">
								<img src="<?php echo base_url(); ?>assets/images/g2.jpg" class="img-responsive zoom-img" alt="" />
							</a>
						</div>
						<div class="news-gridimgtext">
							<a href="single.html">
								<h4>electrical services </h4>
							</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer gravida mauris non mi gravida, at sollicitudin. </p>
						</div>
					</div>
				</div>

				<div class=" col-md-4 col-sm-6 about-innergrids">
					<div class="agileits-news-gridtext">
						<div class="news-gridimg">
							<a href="single.html">
								<img src="<?php echo base_url(); ?>assets/images/r1.jpg" class="img-responsive zoom-img" alt="" />
							</a>
						</div>
						<div class="news-gridimgtext">
							<a href="single.html">
								<h4>painting services </h4>
							</a>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer gravida mauris non mi gravida, at sollicitudin. </p>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>

			</div>
		</div>
	</div>
	<!-- //what we do -->

	<!-- team -->
	<div id="team" class="w3ls-section team">
		<div class="container">
			<h4 class="main-title">meet Our Team</h4>
			<div class="services-main">
				<div class="col-md-7 team-grid1">
					<!-- <h4 class="sub1">your complete home solution</h4> -->
					<h4 class="sub1">our dynamic and dedicated team working towards building one stop solution!</h4>
				</div>
				<div class="col-md-5 team-main-grid">
					<div class="team-row">
						<div class="col-md-6 col-xs-6 team-grids">
							<div class="team-gridimg">
								<img class="img-responsive" src="<?php echo base_url(); ?>assets/images/m1.jpg" alt="">
								<div class="captn">
									<div class="captn-top">
										<h4>Nathan</h4>
										<p>Managing Director</p>
									</div>
									<div class="social-teamicon teaminfo-social-grids">
										<ul>
											<li>
												<a href="#">
													<span class="fa fa-facebook"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-twitter"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-rss"></span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xs-6 team-grids">
							<div class="team-gridimg">
								<img class="img-responsive" src="<?php echo base_url(); ?>assets/images/m2.jpg" alt="">
								<div class="captn">
									<div class="captn-top">
										<h4>Hoover</h4>
										<p>Human Resources</p>
									</div>
									<div class="social-teamicon teaminfo-social-grids">
										<ul>
											<li>
												<a href="#">
													<span class="fa fa-facebook"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-twitter"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-rss"></span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xs-6 team-grids">
							<div class="team-gridimg">
								<img class="img-responsive" src="<?php echo base_url(); ?>assets/images/m3.jpg" alt="">
								<div class="captn">
									<div class="captn-top">
										<h4>James</h4>
										<p>Chief Risk Officer</p>
									</div>
									<div class="social-teamicon teaminfo-social-grids">
										<ul>
											<li>
												<a href="#">
													<span class="fa fa-facebook"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-twitter"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-rss"></span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-xs-6 team-grids">
							<div class="team-gridimg">
								<img class="img-responsive" src="<?php echo base_url(); ?>assets/images/m4.jpg" alt="">
								<div class="captn">
									<div class="captn-top">
										<h4>Sturgill</h4>
										<p>Chief Financial Officer</p>
									</div>
									<div class="social-teamicon teaminfo-social-grids">
										<ul>
											<li>
												<a href="#">
													<span class="fa fa-facebook"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-twitter"></span>
												</a>
											</li>
											<li>
												<a href="#">
													<span class="fa fa-rss"></span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>

				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //team -->

	<!--client-->
	<div class="testimonials w3ls-section" hidden>
		<div class="container">
			<h4 class="main-title">what our Client Says</h4>
			<div class="services-main  client">
				<!--screen-gallery-->
				<div class="sreen-gallery-cursual">

					<div id="owl-demo" class="owl-carousel">
						<div class="item-owl">
							<div class="customer-say">
								<div class="customer-grid">
									<div class="de_testi">
										<div class="quotes">
											<img src="<?php echo base_url(); ?>assets/images/10.jpg" alt="">
										</div>
										<div class="de_testi_by">
											<h6>adipisicing elit</h6>
											<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
												magna aliqua.</p>
											<a href="#">Michael </a>, Customer
										</div>
										<div class="clearfix"></div>
									</div>
								</div>

							</div>
						</div>
						<div class="item-owl">
							<div class="customer-say">
								<div class="customer-grid">
									<div class="de_testi">
										<div class="quotes">
											<img src="<?php echo base_url(); ?>assets/images/11.jpg" alt="">
										</div>
										<div class="de_testi_by">
											<h6>eiusmod tempor</h6>
											<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
												magna aliqua.</p>
											<a href="#">Nelson </a>, Customer
										</div>
										<div class="clearfix"></div>
									</div>
								</div>

							</div>
						</div>
						<div class="item-owl">
							<div class="customer-say">
								<div class="customer-grid">
									<div class="de_testi">
										<div class="quotes">
											<img src="<?php echo base_url(); ?>assets/images/12.jpg" alt="">
										</div>
										<div class="de_testi_by">
											<h6>incididunt labore</h6>
											<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
												magna aliqua.</p>
											<a href="#">Luis </a>, Customer
										</div>
										<div class="clearfix"></div>
									</div>
								</div>

							</div>
						</div>

					</div>
					<!--//screen-gallery-->
				</div>
			</div>
			<!--//client-->
		</div>
	</div>

	
	